module.exports = {
  type: 'transform',
  esbuild: {
    target: 'esnext',
  },
};
