const BASE_URL = 'http://localhost:8123/';

export { BASE_URL };
