import { enhance11tydata } from '../util/i18n';

module.exports = () => {
  return enhance11tydata({}, __dirname);
};
